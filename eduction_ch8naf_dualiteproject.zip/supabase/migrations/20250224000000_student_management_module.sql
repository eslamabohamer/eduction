/*
  # Student Management Module Schema
  
  ## Query Description:
  This migration adds the necessary tables and columns for the comprehensive student management system.
  It includes attendance tracking, behavior notes, financial records, and extended profile details.

  ## Metadata:
  - Schema-Category: "Structural"
  - Impact-Level: "Medium"
  - Requires-Backup: false
  - Reversible: true

  ## Structure Details:
  - `student_profiles`: Added parent info, address, contacts.
  - `attendance_records`: New table for tracking daily attendance.
  - `behavior_notes`: New table for teacher notes on student behavior.
  - `financial_records`: New table for tracking fees and payments.
*/

-- Add extended fields to student_profiles
ALTER TABLE public.student_profiles 
ADD COLUMN IF NOT EXISTS parent_name text,
ADD COLUMN IF NOT EXISTS parent_phone text,
ADD COLUMN IF NOT EXISTS parent_email text,
ADD COLUMN IF NOT EXISTS address text,
ADD COLUMN IF NOT EXISTS emergency_contact text,
ADD COLUMN IF NOT EXISTS notes text;

-- Create Attendance Records Table
CREATE TABLE IF NOT EXISTS public.attendance_records (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    student_id uuid REFERENCES public.student_profiles(id) ON DELETE CASCADE NOT NULL,
    date date NOT NULL DEFAULT CURRENT_DATE,
    status text NOT NULL CHECK (status IN ('present', 'absent', 'late', 'excused')),
    notes text,
    tenant_id uuid, -- Assuming multi-tenancy is handled via RLS or application logic
    created_at timestamptz DEFAULT now(),
    created_by uuid REFERENCES auth.users(id)
);

-- Create Behavior Notes Table
CREATE TABLE IF NOT EXISTS public.behavior_notes (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    student_id uuid REFERENCES public.student_profiles(id) ON DELETE CASCADE NOT NULL,
    title text NOT NULL,
    description text,
    type text NOT NULL CHECK (type IN ('positive', 'negative', 'neutral')),
    created_at timestamptz DEFAULT now(),
    created_by uuid REFERENCES auth.users(id),
    tenant_id uuid
);

-- Create Financial Records Table
CREATE TABLE IF NOT EXISTS public.financial_records (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    student_id uuid REFERENCES public.student_profiles(id) ON DELETE CASCADE NOT NULL,
    amount numeric(10, 2) NOT NULL,
    type text NOT NULL CHECK (type IN ('payment', 'fee', 'discount')),
    description text,
    date date DEFAULT CURRENT_DATE,
    status text DEFAULT 'completed' CHECK (status IN ('completed', 'pending', 'overdue', 'cancelled')),
    created_at timestamptz DEFAULT now(),
    created_by uuid REFERENCES auth.users(id),
    tenant_id uuid
);

-- Add RLS Policies (Assuming standard public access for authenticated users for this demo, 
-- in production these should be scoped to tenant_id)

ALTER TABLE public.attendance_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.behavior_notes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.financial_records ENABLE ROW LEVEL SECURITY;

-- Simple policies for authenticated users (Teachers)
CREATE POLICY "Teachers can view attendance" ON public.attendance_records FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Teachers can insert attendance" ON public.attendance_records FOR INSERT WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "Teachers can update attendance" ON public.attendance_records FOR UPDATE USING (auth.role() = 'authenticated');
CREATE POLICY "Teachers can delete attendance" ON public.attendance_records FOR DELETE USING (auth.role() = 'authenticated');

CREATE POLICY "Teachers can view behavior" ON public.behavior_notes FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Teachers can insert behavior" ON public.behavior_notes FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Teachers can view finances" ON public.financial_records FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Teachers can insert finances" ON public.financial_records FOR INSERT WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "Teachers can update finances" ON public.financial_records FOR UPDATE USING (auth.role() = 'authenticated');
