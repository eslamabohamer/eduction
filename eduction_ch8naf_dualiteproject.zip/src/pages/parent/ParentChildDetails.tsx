// src/pages/parent/ParentChildDetails.tsx
// صفحة تفاصيل الابن (نسخة ولي الأمر)
// Detailed view for a specific child, reusing existing components in read-only mode.

import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { studentService, StudentWithUser } from '@/services/studentService';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { ArrowRight, QrCode } from 'lucide-react';
import { toast } from 'sonner';

// Reusing components
import { StudentAttendance } from '@/components/students/StudentAttendance';
import { StudentFinancials } from '@/components/students/StudentFinancials';
import { StudentBehavior } from '@/components/students/StudentBehavior';
import { StudentAcademic } from '@/components/students/StudentAcademic';
import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog';
import { StudentQRCode } from '@/components/secretary/StudentQRCode';

export default function ParentChildDetails() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [student, setStudent] = useState<StudentWithUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) loadStudent();
  }, [id]);

  async function loadStudent() {
    try {
      // We use the same service, RLS ensures parent can only fetch their own child
      const data = await studentService.getStudentById(id!);
      setStudent(data);
    } catch (error) {
      console.error(error);
      toast.error('فشل تحميل بيانات الطالب');
      navigate('/parent/dashboard');
    } finally {
      setLoading(false);
    }
  }

  if (loading) return <div className="p-8 text-center">جاري التحميل...</div>;
  if (!student) return null;

  return (
    <div className="space-y-6 pb-10">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => navigate('/parent/dashboard')}>
          <ArrowRight className="h-5 w-5" />
        </Button>
        <h1 className="text-2xl font-bold">تفاصيل الطالب</h1>
      </div>

      {/* Profile Card */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-6 items-center md:items-start">
            <Avatar className="h-24 w-24 border-2 border-primary/10">
              <AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${student.user.name}`} />
              <AvatarFallback>{student.user.name[0]}</AvatarFallback>
            </Avatar>
            
            <div className="flex-1 text-center md:text-right">
              <h2 className="text-2xl font-bold">{student.user.name}</h2>
              <div className="flex flex-col md:flex-row items-center gap-2 text-muted-foreground mt-1">
                <Badge variant="secondary" className="font-mono">{student.student_code}</Badge>
                <span>• {student.level} - {student.grade}</span>
              </div>
            </div>

            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" className="gap-2">
                  <QrCode className="h-4 w-4" />
                  البطاقة المدرسية
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <StudentQRCode 
                  studentName={student.user.name} 
                  studentCode={student.student_code} 
                />
              </DialogContent>
            </Dialog>
          </div>
        </CardContent>
      </Card>

      {/* Tabs */}
      <Tabs defaultValue="academic" className="w-full">
        <TabsList className="w-full justify-start h-auto p-1 bg-muted/50 overflow-x-auto">
          <TabsTrigger value="academic" className="flex-1 min-w-[100px]">الأداء الأكاديمي</TabsTrigger>
          <TabsTrigger value="attendance" className="flex-1 min-w-[100px]">الحضور</TabsTrigger>
          <TabsTrigger value="financial" className="flex-1 min-w-[100px]">المالية</TabsTrigger>
          <TabsTrigger value="behavior" className="flex-1 min-w-[100px]">السلوك</TabsTrigger>
        </TabsList>

        <div className="mt-6">
          <TabsContent value="academic">
            <StudentAcademic studentId={student.id} />
          </TabsContent>
          
          <TabsContent value="attendance">
            <StudentAttendance studentId={student.id} readOnly />
          </TabsContent>
          
          <TabsContent value="financial">
            <StudentFinancials studentId={student.id} readOnly />
          </TabsContent>
          
          <TabsContent value="behavior">
            <StudentBehavior studentId={student.id} readOnly />
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
}
