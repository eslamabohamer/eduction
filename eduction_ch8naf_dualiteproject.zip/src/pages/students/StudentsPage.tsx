// src/pages/students/StudentsPage.tsx
// تحديث الصفحة لإضافة الحقول الجديدة وروابط التفاصيل
// Update page with new fields and link to details.

import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { studentService, StudentWithUser } from '@/services/studentService';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Plus, Search, QrCode, Eye } from 'lucide-react';
import { toast } from 'sonner';
import { StudentQuickView } from '@/components/students/StudentQuickView';

export default function StudentsPage() {
  const [students, setStudents] = useState<StudentWithUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Form state
  const [formData, setFormData] = useState({
    name: '',
    username: '',
    grade: '',
    level: '',
    parent_name: '',
    parent_phone: '',
    address: ''
  });

  useEffect(() => {
    loadStudents();
  }, []);

  async function loadStudents() {
    try {
      const data = await studentService.getStudents();
      setStudents(data);
    } catch (error) {
      console.error(error);
      toast.error('فشل تحميل قائمة الطلاب');
    } finally {
      setLoading(false);
    }
  }

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    try {
      await studentService.createStudent(formData);
      toast.success('تم إضافة الطالب بنجاح');
      setIsDialogOpen(false);
      setFormData({ 
        name: '', username: '', grade: '', level: '',
        parent_name: '', parent_phone: '', address: ''
      });
      loadStudents();
    } catch (error) {
      console.error(error);
      toast.error('فشل إضافة الطالب');
    }
  }

  const filteredStudents = students.filter(s => 
    s.user.name.toLowerCase().includes(search.toLowerCase()) ||
    s.student_code.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">الطلاب</h1>
        <div className="flex gap-2">
          <StudentQuickView />
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                إضافة طالب
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>إضافة طالب جديد</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleCreate} className="space-y-4 mt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>اسم الطالب</Label>
                    <Input 
                      required 
                      value={formData.name}
                      onChange={e => setFormData({...formData, name: e.target.value})}
                      placeholder="مثال: محمد أحمد"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>اسم المستخدم (للدخول)</Label>
                    <Input 
                      required 
                      value={formData.username}
                      onChange={e => setFormData({...formData, username: e.target.value})}
                      placeholder="مثال: mohamed2024"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>المرحلة</Label>
                    <Input 
                      required 
                      value={formData.level}
                      onChange={e => setFormData({...formData, level: e.target.value})}
                      placeholder="مثال: الثانوية"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>الصف</Label>
                    <Input 
                      required 
                      value={formData.grade}
                      onChange={e => setFormData({...formData, grade: e.target.value})}
                      placeholder="مثال: الأول الثانوي"
                    />
                  </div>
                </div>

                <div className="border-t pt-4 mt-2">
                  <h4 className="text-sm font-medium mb-3 text-muted-foreground">بيانات ولي الأمر والاتصال</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>اسم ولي الأمر</Label>
                      <Input 
                        value={formData.parent_name}
                        onChange={e => setFormData({...formData, parent_name: e.target.value})}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>رقم الهاتف</Label>
                      <Input 
                        value={formData.parent_phone}
                        onChange={e => setFormData({...formData, parent_phone: e.target.value})}
                        placeholder="01xxxxxxxxx"
                      />
                    </div>
                    <div className="space-y-2 col-span-2">
                      <Label>العنوان</Label>
                      <Input 
                        value={formData.address}
                        onChange={e => setFormData({...formData, address: e.target.value})}
                      />
                    </div>
                  </div>
                </div>

                <Button type="submit" className="w-full mt-4">حفظ</Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute right-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="بحث بالاسم أو الكود..."
            className="pr-9"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-right">الاسم</TableHead>
              <TableHead className="text-right">الكود</TableHead>
              <TableHead className="text-right">المرحلة / الصف</TableHead>
              <TableHead className="text-right">ولي الأمر</TableHead>
              <TableHead className="text-right">إجراءات</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-8">جاري التحميل...</TableCell>
              </TableRow>
            ) : filteredStudents.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">لا يوجد طلاب مضافين</TableCell>
              </TableRow>
            ) : (
              filteredStudents.map((student) => (
                <TableRow key={student.id}>
                  <TableCell className="font-medium">{student.user.name}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <QrCode className="h-4 w-4 text-muted-foreground" />
                      <span className="font-mono text-xs">{student.student_code}</span>
                    </div>
                  </TableCell>
                  <TableCell>{student.level} - {student.grade}</TableCell>
                  <TableCell>{student.parent_phone || '-'}</TableCell>
                  <TableCell>
                    <Link to={`/students/${student.id}`}>
                      <Button variant="ghost" size="sm" className="gap-2">
                        <Eye className="h-4 w-4" />
                        عرض الملف
                      </Button>
                    </Link>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
