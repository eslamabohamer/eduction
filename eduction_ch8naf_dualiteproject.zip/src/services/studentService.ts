// src/services/studentService.ts
// خدمة إدارة الطلاب
// Handles student fetching, creation, and extended management operations.

import { supabase } from '@/lib/supabase';
import { StudentProfile, User, AttendanceRecord, BehaviorNote, FinancialRecord } from '@/types';

export interface StudentWithUser extends StudentProfile {
  user: User;
}

export const studentService = {
  /**
   * Fetch all students for the current tenant
   * جلب جميع الطلاب للمستأجر الحالي
   */
  async getStudents() {
    const { data, error } = await supabase
      .from('student_profiles')
      .select(`
        *,
        user:users(*)
      `);
    
    if (error) throw error;
    return data as StudentWithUser[];
  },

  /**
   * Get single student details
   * جلب تفاصيل طالب واحد
   */
  async getStudentById(id: string) {
    const { data, error } = await supabase
      .from('student_profiles')
      .select(`
        *,
        user:users(*)
      `)
      .eq('id', id)
      .single();
      
    if (error) throw error;
    return data as StudentWithUser;
  },

  /**
   * Create a new student record
   * إنشاء سجل طالب جديد
   */
  async createStudent(data: {
    name: string;
    username: string;
    grade: string;
    level: string;
    dateOfBirth?: Date;
    // Extended fields
    parent_name?: string;
    parent_phone?: string;
    address?: string;
  }) {
    // 1. Call RPC to create user and basic profile
    const { data: result, error } = await supabase.rpc('create_student_record', {
      p_name: data.name,
      p_username: data.username,
      p_grade: data.grade,
      p_level: data.level,
      p_dob: data.dateOfBirth ? data.dateOfBirth.toISOString() : null
    });

    if (error) throw error;

    // 2. Update extended profile fields if provided
    if (data.parent_name || data.parent_phone || data.address) {
      const { error: updateError } = await supabase
        .from('student_profiles')
        .update({
          parent_name: data.parent_name,
          parent_phone: data.parent_phone,
          address: data.address
        })
        .eq('id', result);

      if (updateError) console.error('Failed to update extended profile info', updateError);
    }

    return result;
  },

  /**
   * Update student profile
   * تحديث بيانات الطالب
   */
  async updateStudent(id: string, data: Partial<StudentProfile> & { name?: string }) {
    // Update profile fields
    const profileUpdates: any = {};
    if (data.grade) profileUpdates.grade = data.grade;
    if (data.level) profileUpdates.level = data.level;
    if (data.parent_name) profileUpdates.parent_name = data.parent_name;
    if (data.parent_phone) profileUpdates.parent_phone = data.parent_phone;
    if (data.address) profileUpdates.address = data.address;
    if (data.emergency_contact) profileUpdates.emergency_contact = data.emergency_contact;

    if (Object.keys(profileUpdates).length > 0) {
      const { error } = await supabase
        .from('student_profiles')
        .update(profileUpdates)
        .eq('id', id);
      if (error) throw error;
    }

    // Update user name if provided
    if (data.name) {
      // We need the user_id first
      const { data: profile } = await supabase
        .from('student_profiles')
        .select('user_id')
        .eq('id', id)
        .single();
        
      if (profile) {
        const { error: userError } = await supabase
          .from('users')
          .update({ name: data.name })
          .eq('auth_id', profile.user_id); // Assuming auth_id link, or use id if users table uses uuid
        
        if (userError) throw userError;
      }
    }
  },

  /**
   * Find student by code (for barcode scanner)
   * البحث عن طالب بالكود
   */
  async getStudentByCode(code: string) {
    const { data, error } = await supabase
      .from('student_profiles')
      .select(`
        *,
        user:users(*)
      `)
      .eq('student_code', code)
      .single();
      
    if (error) throw error;
    return data as StudentWithUser;
  },

  // --- Attendance Operations (عمليات الحضور) ---

  async getAttendance(studentId: string) {
    const { data, error } = await supabase
      .from('attendance_records')
      .select('*')
      .eq('student_id', studentId)
      .order('date', { ascending: false });
      
    if (error) throw error;
    return data as AttendanceRecord[];
  },

  async addAttendance(record: Omit<AttendanceRecord, 'id' | 'created_at'>) {
    const { error } = await supabase
      .from('attendance_records')
      .insert(record);
      
    if (error) throw error;
  },

  // --- Behavior Operations (عمليات السلوك) ---

  async getBehaviorNotes(studentId: string) {
    const { data, error } = await supabase
      .from('behavior_notes')
      .select('*')
      .eq('student_id', studentId)
      .order('created_at', { ascending: false });
      
    if (error) throw error;
    return data as BehaviorNote[];
  },

  async addBehaviorNote(note: Omit<BehaviorNote, 'id' | 'created_at' | 'created_by'>) {
    const { error } = await supabase
      .from('behavior_notes')
      .insert(note);
      
    if (error) throw error;
  },

  // --- Financial Operations (العمليات المالية) ---

  async getFinancialRecords(studentId: string) {
    const { data, error } = await supabase
      .from('financial_records')
      .select('*')
      .eq('student_id', studentId)
      .order('date', { ascending: false });
      
    if (error) throw error;
    return data as FinancialRecord[];
  },

  async addFinancialRecord(record: Omit<FinancialRecord, 'id' | 'created_at'>) {
    const { error } = await supabase
      .from('financial_records')
      .insert(record);
      
    if (error) throw error;
  },

  // --- Academic Stats (الإحصائيات الأكاديمية) ---
  
  async getAcademicStats(studentId: string) {
    // Get Exam Submissions
    const { data: exams, error: examError } = await supabase
      .from('exam_submissions')
      .select(`
        score,
        exam:exams(title, total_marks)
      `)
      .eq('student_id', studentId);

    if (examError) throw examError;

    // Get Homework Submissions
    const { data: homeworks, error: hwError } = await supabase
      .from('homework_submissions')
      .select(`
        grade,
        homework:homework(title)
      `)
      .eq('student_id', studentId);

    if (hwError) throw hwError;

    return {
      exams: exams.map(e => ({
        name: e.exam?.title || 'Unknown',
        score: e.score,
        total: e.exam?.total_marks || 100,
        percentage: (e.score / (e.exam?.total_marks || 100)) * 100
      })),
      homeworks: homeworks.map(h => ({
        name: h.homework?.title || 'Unknown',
        score: h.grade || 0,
        total: 10
      }))
    };
  }
};
